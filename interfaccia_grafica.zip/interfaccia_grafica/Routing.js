const express = require('express');
const app = express()
const path = require('path');

const porta = 3780

app.use(express.static(path.join(__dirname, 'public')));

app.use('/css', express.static(path.join(__dirname, 'node_modules/bootstrap/dist/css')));
app.use('/js', express.static(path.join(__dirname, 'node_modules/bootstrap/dist/js')));

app.get('/', (req, res) => {
  
  res.sendFile(__dirname + "/vetrina.html");
})

app.get('/carrello', (req, res) => {
  res.sendFile(__dirname + "/carrello.html");
})

app.get('/registrati', (req, res) => {
  res.sendFile(__dirname + "/registrati.html");
})

app.get('/autenticazione', (req, res) => {
  res.sendFile(__dirname + "/autenticazione.html");
})

/*app.get('/script_interfaccia', (req, res) => {
  res.sendFile(__dirname + "/script_interfaccia.js");
})*/

app.get('/contatti', (req, res) => {
  res.sendFile(__dirname + "/contatti.html");
})

app.listen(porta, () => {
  console.log('Servizio in ascolto sulla porta: ' + porta)
})
